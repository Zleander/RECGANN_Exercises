package de.cogmod.spacecombat.simulation;



/**
 * @author Sebastian Otte
 */
public interface SpaceSimulationObserver {
	
    public void simulationStep(final SpaceSimulation sim);
   
}